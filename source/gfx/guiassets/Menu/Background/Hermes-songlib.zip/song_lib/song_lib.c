/*
Copyright (c) 2008 Francisco Mu�oz 'Hermes' <www.elotrolado.net>
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are 
permitted provided that the following conditions are met:

- Redistributions of source code must retain the above copyright notice, this list of 
  conditions and the following disclaimer. 
- Redistributions in binary form must reproduce the above copyright notice, this list 
  of conditions and the following disclaimer in the documentation and/or other 
  materials provided with the distribution. 
- The names of the contributors may not be used to endorse or promote products derived 
  from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY 
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF 
THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/


#include "song_lib.h"
#include "drum.h"

typedef struct 
{
s32 ind;

u8 * tabnotes;
u8 flag;

u32 time_fornext;

s32 octave;  
s32 lvolume;
s32 rvolume;

s32 typenote; // 0 to 8  (semi-corchea a redonda)

s32 tempo;

s32 compass_down;

s32 channel;

s32 instrument;
s32 sync;

int triplet;
int triplet_time;

int memory_pieces;
void *memory_end[32]; // stack for Memory pieces

u8 *mem_start[16];
u8 *mem_end[16];

} Song;

static Song my_song[3];

static void (* song_callback)(s32 channel, s32 instrument, s32 note, s32 time, s32 lvolume, s32 rvolume)=NULL;


static s32 get_note_time(Song *s)
{
u32 v=(s->typenote>>1);
u32 temp;

temp=SND_GetAudioRate()*s->tempo;


temp=((temp*s->compass_down)/8000);

//temp=(temp/SND_GetSamplesPerTick())*SND_GetSamplesPerTick();
if(temp==0) temp=SND_GetSamplesPerTick();

if(v==0) v=1;
	v=(temp)*(v<<1);
if(s->typenote & 1) return (v+(v>>1));
else return v;
}



static int ctrl_song=0;


static u8 * skip_spaces(u8 *c)
{

while(* c<=32 || *c=='|')
	{
	if(*c==0) break;
	c++;
	}
return c;
}


static void process_song(Song *s, u32 time)
{
u8 *c;
int n;

if(s->flag & 128) // special case of sync
  {
  if(time<s->time_fornext) {return;}
  if(s->sync==128) s->sync=1; // send the signal for sync
  return;
  }

if(!s->tabnotes || (s->flag & 128)!=0) {s->flag|=128;return;}


c=s->tabnotes;

itera:

c=skip_spaces(c);

if(*c==0) {s->flag|=128;return;}


s->tabnotes=c;



if(*c=='(') // add to MEM
{

c++;
if(s->memory_pieces>=8) {s->flag|=128 | SONG_ERR_PARENTHESIS;return;}
s->memory_pieces++;
s->mem_start[s->memory_pieces]=c;


while(c[0]!=')') 
{
if(c[0]==0 || c[0]=='(') {s->flag|=128 | SONG_ERR_PARENTHESIS;return;}
c++;
}
c++;

s->mem_end[s->memory_pieces]=c;
s->tabnotes=c;goto itera;
}

if(*c==')')
{
c++;
if(s->memory_end[0]) {c=s->memory_end[0];for(n=0;n<31;n++) s->memory_end[n]=s->memory_end[n+1];s->memory_end[n]=0;goto itera;}
}
if(*c=='M') // set memory
	{
	c++;
    if(*c>='0' && *c<='9')
		{
        int a;
		a=(*c -48);
		c++;
		if(a<=s->memory_pieces) {for(n=0;n<31;n++) s->memory_end[31-n]=s->memory_end[30-n]; s->memory_end[0]=c; c=s->mem_start[a];goto itera;}
		}
	else {s->flag|=128 | SONG_ERR_CHN;return;}
	}
if(*c>='0' && *c<='9')
	{
	s->typenote=(*c -48);

	c++;goto itera;
	}
if(*c=='-')
	{
	if(s->octave>0) s->octave--;
	c++;goto itera;	
	}

if(*c=='+')
	{
  
	if(s->octave<7) s->octave++;
	c++;goto itera;
		
	}

if(*c=='T') // change Tempo
	{
	c++;
    if(*c=='2' || *c=='4'  || *c=='8')
		{
		s->compass_down=(*c -48);
		c++;goto itera;
		}
	else {s->flag|=128 | SONG_ERR_TEMPO;return;}
	}

if(*c=='X') // set instrument
	{
	c++;
    if(*c>='0' && *c<='9')
		{
		s->instrument=(*c -48);
		c++;goto itera;
		}
	else {s->flag|=128 | SONG_ERR_CHN;return;}
	}

if(*c=='O') // change octave
	{
	c++;
    if(*c>='0' && *c<='8')
		{
		s->octave=(*c -48);
		c++;goto itera;
		}
	else {s->flag|=128 | SONG_ERR_OCT;return;}
	}

if(*c=='V') // change channel
	{
	c++;
    if(*c>='0' && *c<='9')
		{
		s->lvolume=(255*(*c -48))/9;
		c++;
		}
	else {s->flag|=128 | SONG_ERR_CHN;return;}
	 if(*c>='0' && *c<='9')
		{
		s->rvolume=(255*(*c -48))/9;
		c++;goto itera;
		}
	else {s->flag|=128 | SONG_ERR_CHN;return;}
	}
if(*c==')' || *c=='(') goto itera;

if(*c=='!') // sync symbol
{     
 s->sync=128; // prepare the signal for sync
 c++;goto itera;
}

if(*c=='?') // sync symbol
{
 if(s->sync==128)   s->sync=1;   
 if(s->sync!=2) {s->tabnotes=c;return;} // wait for sync
 s->sync=0;
 s->time_fornext=time; // Warning!: this can break one note
 c++;goto itera;
 
}

if((*c>='a' && *c<='g') || (*c>='A' && *c<='G') || *c=='&' || *c=='t' )
	{
	s32 note=0;
	u32 time2;
	
	if(s->triplet)
		{
		if(time<(s->time_fornext+(s->triplet_time*s->triplet)/3)) {s->tabnotes=c;return;}
		s->triplet++;
		}
	else
	if(time<s->time_fornext) {s->tabnotes=c;return;}
	
	 if(s->sync==128) s->sync=1; // send the signal for sync

	if(s->channel<0) {s->flag|=128;return;}

	if(*c == 't')
		 {s->triplet=1;
          s->triplet_time=get_note_time(s)*2;
		  c++;
           if(*c==0) {s->flag|=128;return;}
		 }
		 

	if(*c=='&') note=-1;
	else
	{
    if(*c<'a') note+=12;
	switch((*c-65) & 15)
		{
		case 0:note+=9;if(c[1]=='#') {c++;note++;}
                       else if(c[1]=='$') {c++;note--;}
                       break;
		case 1:note+=11;if(c[1]=='$') {c++;note--;}break;
		case 2:note+=0;if(c[1]=='#') {c++;note++;}break;
		case 3:note+=2;if(c[1]=='#') {c++;note++;}
		               else if(c[1]=='$') {c++;note--;}
                       break;
		case 4:note+=4;if(c[1]=='$') {c++;note--;}break;
		case 5:note+=5;if(c[1]=='#') {c++;note++;}break;
		case 6:note+=7;if(c[1]=='#') {c++;note++;}
                       else if(c[1]=='$') {c++;note--;}
                       break;
		}
	
    note+=12*s->octave;
	}

	if(s->triplet)
	{
	time2=(s->triplet_time)/3;
	if(s->triplet==3) {s->triplet=0;s->time_fornext+=s->triplet_time;}
	}
	else
	{ // no triplet
    time2=get_note_time(s);
 
	s->time_fornext=time+time2;
	c++;
	c=skip_spaces(c);
    if(*c==0) {s->flag|=128;}

    if(*c>='0' && *c<='9')
	{
	s->typenote=(*c -48);

	c++;
	c=skip_spaces(c);
    if(*c==0) {s->flag|=128;}
	}
    if(*c=='!') // sync symbol
    {     
    s->sync=128; // prepare the signal for sync
    c++;
    }
	if(c[0]=='*') // nota ligada
	{
	do
	 {
	 c++;
     time2+=get_note_time(s);
	 s->time_fornext+=get_note_time(s);
     c=skip_spaces(c);
     if(*c==0) {s->flag|=128;}
	 if(*c>='0' && *c<='9')
	 {
	 s->typenote=(*c -48);

	 c++;
	 }
	 if(*c=='!') // sync symbol
     {     
     s->sync=128; // prepare the signal for sync
     c++;
     }

	 } while(c[0]=='*');


	}
	
	c--;
	} // no triplet
	
	if(*c==')') c--;
	else
	if(*c=='(') c--;

	//if(s->compass_counter>=get_compass_time(s)) s->compass_counter=0;
	
    if(note>=0)
		{
        
		time2=time2/48; // pasa ticks a ms
		
        s->channel&=127; // disable flag
        
        if(s->ind==2) // drum
          {
          note-=12*s->octave;
          switch(note)
          {
          case 0:
          case 1:
               SND_SetSongSampleVoice(s->channel, VOICE_MONO_8BIT, drum_bass_smp, NULL, size_drum_bass_smp);
               SND_PlaySongVoice(s->channel, Note2Freq(NOTE(NOTE_C,3), 8000, NOTE(NOTE_C,3)), 0, 0, time2, 0, s->lvolume, s->rvolume);
               break;
          case 2:
          case 3:
               SND_SetSongSampleVoice(s->channel, VOICE_MONO_8BIT, drum_floortom_smp, NULL, size_drum_floortom_smp);
               SND_PlaySongVoice(s->channel, Note2Freq(NOTE(NOTE_C,3), 8000, NOTE(NOTE_C,3)), 0, 0, 0, time2, s->lvolume, s->rvolume);
               break;
          case 4:
               SND_SetSongSampleVoice(s->channel, VOICE_MONO_8BIT, drum_floortom_smp, NULL, size_drum_floortom_smp);
               SND_PlaySongVoice(s->channel, Note2Freq(NOTE(NOTE_D,3), 8000, NOTE(NOTE_C,3)), 0, 0, 0,time2, s->lvolume, s->rvolume);
               break; 
               
          case 5:
          case 6:
               SND_SetSongSampleVoice(s->channel, VOICE_MONO_8BIT, drum_tom_smp, NULL, size_drum_tom_smp);
               SND_PlaySongVoice(s->channel, Note2Freq(NOTE(NOTE_F,3), 8000, NOTE(NOTE_C,3)), 0, 0, 0,time2, s->lvolume, s->rvolume);
               break;   
          case 7:
          case 8:
               SND_SetSongSampleVoice(s->channel, VOICE_MONO_8BIT, drum_tom_smp, NULL, size_drum_tom_smp);
               SND_PlaySongVoice(s->channel, Note2Freq(NOTE(NOTE_E,3), 8000, NOTE(NOTE_C,3)), 0, 0, 0,time2, s->lvolume, s->rvolume);
               break;  
          case 9:
          case 10:
               SND_SetSongSampleVoice(s->channel, VOICE_MONO_8BIT, drum_tom_smp, NULL, size_drum_tom_smp);
               SND_PlaySongVoice(s->channel, Note2Freq(NOTE(NOTE_D,3), 8000, NOTE(NOTE_C,3)), 0, 0, 0,time2, s->lvolume, s->rvolume);
               break;  
          case 11:
               SND_SetSongSampleVoice(s->channel, VOICE_MONO_8BIT, drum_tom_smp, NULL, size_drum_tom_smp);
               SND_PlaySongVoice(s->channel, Note2Freq(NOTE(NOTE_C,3), 8000, NOTE(NOTE_C,3)), 0, 0, 0,time2, s->lvolume, s->rvolume);
               break;   
               
          case 12:
          case 13:
               SND_SetSongSampleVoice(s->channel, VOICE_MONO_8BIT, drum_cymbal_smp, NULL, size_drum_cymbal_smp);
               SND_PlaySongVoice(s->channel, Note2Freq(NOTE(NOTE_C,3), 11025, NOTE(NOTE_C,3)), 0, 0, time2, 0, s->lvolume, s->rvolume);
               break;
          case 14:
          case 15:
               SND_SetSongSampleVoice(s->channel, VOICE_MONO_8BIT, drum_cymbal_smp, NULL, size_drum_cymbal_smp);
               SND_PlaySongVoice(s->channel, Note2Freq(NOTE(NOTE_D,3), 11025, NOTE(NOTE_C,3)), 0, 0, time2, 0, s->lvolume, s->rvolume);
               break;
          case 16:
               SND_SetSongSampleVoice(s->channel, VOICE_MONO_8BIT, drum_cymbal_smp, NULL, size_drum_cymbal_smp);
               SND_PlaySongVoice(s->channel, Note2Freq(NOTE(NOTE_F,3), 11025, NOTE(NOTE_C,3)), 0, 0,time2, 0, s->lvolume, s->rvolume);
               break;
                    
          case 17:
          case 18:
               SND_SetSongSampleVoice(s->channel, VOICE_MONO_8BIT, drum_cymbal_smp, NULL, size_drum_cymbal_smp);
               SND_PlaySongVoice(s->channel, Note2Freq(NOTE(NOTE_C,3), 11025, NOTE(NOTE_C,3)), 0, 0, 0, time2, s->lvolume, s->rvolume);
               break;
          case 19:
          case 20:
               SND_SetSongSampleVoice(s->channel, VOICE_MONO_8BIT, drum_cymbal_smp, NULL, size_drum_cymbal_smp);
               SND_PlaySongVoice(s->channel, Note2Freq(NOTE(NOTE_D,3), 11025, NOTE(NOTE_C,3)), 0, 0, 0, time2, s->lvolume, s->rvolume);
               break;
          case 21:
          case 22:
               SND_SetSongSampleVoice(s->channel, VOICE_MONO_8BIT, drum_cymbal_smp, NULL, size_drum_cymbal_smp);
               SND_PlaySongVoice(s->channel, Note2Freq(NOTE(NOTE_F,3), 11025, NOTE(NOTE_C,3)), 0, 0, 0,time2, s->lvolume, s->rvolume);
               break;
          case 23:
               SND_SetSongSampleVoice(s->channel, VOICE_MONO_8BIT, drum_cymbal_smp, drum_cymbal_smp+4672, size_drum_cymbal_smp);
               SND_PlaySongVoice(s->channel, Note2Freq(NOTE(NOTE_F,3), 11025, NOTE(NOTE_C,3)), 0, 0, 0, time2, s->lvolume, s->rvolume);
               break;        
          
          
          }
               
          }
        else
		if(song_callback) (*song_callback)(s->channel, s->instrument, note, time2, s->lvolume, s->rvolume);

		}
	
 
	}
if(*c!=0) c++;
s->tabnotes=c;
}


static void callback_song()
{
u32 time=SND_GetSampleCounter();
int st;
if(ctrl_song==1) 
  {process_song(&my_song[0], time);
  if(my_song[0].sync==1)// send the sync value
    {my_song[2].sync=my_song[1].sync=2; 
     my_song[0].sync=0;
    }
  process_song(&my_song[1], time);
  if(my_song[1].sync==1)// send the sync value
    {my_song[2].sync=my_song[0].sync=2; 
     my_song[1].sync=0;
     process_song(&my_song[0], time);
    }
  process_song(&my_song[2], time);
   if(my_song[2].sync==1)// send the sync value
    {my_song[1].sync=my_song[0].sync=2; 
     my_song[2].sync=0;
     process_song(&my_song[0], time);
     process_song(&my_song[1], time);
    }

  }
 // prepare for stops 
if((my_song[0].flag & my_song[1].flag & my_song[2].flag & 128)==128) ctrl_song=2;

if(ctrl_song==2) // stops all voices
  {
         
  st=0;
  if(my_song[0].channel<128) 
   {
      if(SND_StatusVoice(my_song[0].channel)==SND_WORKING) {SND_StopVoice(my_song[0].channel);st++;my_song[0].channel|=128;}
   }
  else st++;
  
  if(my_song[1].channel<128) 
   { 
      if(SND_StatusVoice(my_song[1].channel)==SND_WORKING) {SND_StopVoice(my_song[1].channel);st++;my_song[1].channel|=128;}
   }
  else st++;
  
  if(my_song[2].channel<128) 
    {
      if(SND_StatusVoice(my_song[2].channel)==SND_WORKING) {SND_StopVoice(my_song[2].channel);st++;my_song[2].channel|=128;}
    }
  else st++;
  
  if(st==3) ctrl_song=0; // All voices stopped
  }
}

int Test_Song()
{
return ctrl_song;
}

void Stop_Song()
{
int n;
ctrl_song=0;

for(n=0;n<3;n++) my_song[n].flag|=128;

for(n=0;n<3;n++)
{
if(my_song[n].channel<128) 
   {
	if(my_song[n].channel>0) SND_StopVoice(my_song[n].channel);my_song[n].channel|=128;
   }
}  
ctrl_song=0;
 
}



void Play_Song( char *song, char *chord, char *drum, s32 tempo, void (*note_callback)(s32 channel, s32 instrument, s32 note, s32 time, s32 lvolume, s32 rvolume))
{
int n;
int m;
int cont=0;
Song *s;

ctrl_song=0;

for(m=0;m<3;m++)
{

s=&my_song[m];

s->ind=m;
s->sync=0;

s->flag=128;

s->time_fornext=0;

s->octave=3;  
s->lvolume=255;
s->rvolume=255;
s->typenote=4; // 0 to 8  (semi-corchea a redonda)

s->tempo=tempo;

s->compass_down=4;
if(m==0)
    s->tabnotes=(u8 *) song;
else if(m==1)
    s->tabnotes=(u8 *) chord;
else 
    s->tabnotes=(u8 *) drum;
    
   
s->flag=0;
s->channel= (MAX_SND_VOICES-1-cont) | 128;
cont++;
/*if(s->tabnotes) 
  {if(* s->tabnotes!=0) cont++;}
*/
s->instrument=0;
s->triplet=0;
s->memory_pieces=-1;

for(n=0;n<16;n++)
  s->memory_end[n]=NULL;
}
song_callback=note_callback;
SND_SetCallback(callback_song);
SND_SetTime(0);
ctrl_song=1;
}

