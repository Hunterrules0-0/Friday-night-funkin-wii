#ifndef __DRUM_H__
#define __DRUM_H__

#ifdef __cplusplus
extern "C" {
#endif

#define size_drum_bass_smp 1596

extern char drum_bass_smp[1596]; // 8000Hz


#define size_drum_floortom_smp 1376

extern char drum_floortom_smp[1376]; // 8000Hz


#define size_drum_tom_smp 4378

extern char drum_tom_smp[4378]; // 8000Hz


#define size_drum_cymbal_smp 5219

extern char drum_cymbal_smp[5219]; //11025Hz


#ifdef __cplusplus
  }
#endif

#endif
