/*
Copyright (c) 2008 Francisco Mu�oz 'Hermes' <www.elotrolado.net>
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are 
permitted provided that the following conditions are met:

- Redistributions of source code must retain the above copyright notice, this list of 
  conditions and the following disclaimer. 
- Redistributions in binary form must reproduce the above copyright notice, this list 
  of conditions and the following disclaimer in the documentation and/or other 
  materials provided with the distribution. 
- The names of the contributors may not be used to endorse or promote products derived 
  from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY 
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF 
THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/



#ifndef __SONGLIB_H__
#define __SONGLIB_H__


#ifdef __cplusplus
extern "C" {
#endif

#include "snd.h"

#if 0

// NOTE: song_lib uses the last 3 voices to play songs (usually 13,14,15)

/*
 equivalencia de notas y notas usables // equivalent notes

c  -> do
c# -> do sostenido
d$ -> re bemol = c#
d  -> re
d# -> re sostenido
e$ -> mi bemol = d#
e  -> mi
f  -> fa
f# -> fa sostenido
g$ -> sol bemol = f#
g  -> sol
g# -> sol sostenido
a$ -> la bemol = g#
a  -> la
a# -> la sostenido
b$ -> si bemol = a#
b  -> si


 drum notes 

# y $ son ignorados / # and $ are ignored 

c       -> bass

d,e     -> floor tom (different voices)

f,g,a,b -> tom (different voices)

C, D, E -> cymbal (different voices)

F, G, A -> cymbal (short) (different voices)

B       -> cymbal (long)

c-> 
d,e->  (distintas voces)
f,g,a,b -> drum  (distintas voces)
CDE -> drum_ (distintas voces
FGA -> drum_cymbal corto (distintas voces)
B-> drum_cymbal largo 



symbol notation for Play_Song() 

| -> Separador. Funcion decorativa 
     Separator. Decorative function

<n> -> <numero> tiempo de las notas 
       <number> time for notes 
          0 - semicorchea              / sixteenth          / semiquaver
		  1 - semicorchea con puntillo / sixteenth with dot / semiquaver with dot
		  2 - corchea                  / eighth             / quaver
		  3 - corchea con puntillo     / eighth with dot    / quaver with dot
		  4 - negra                    / quarter            / Crotchet
		  5 - negra con puntillo       / quarter with dot   / Crotchet with dot
		  6 - blanca                   / half               / Semibreve
		  7 - blanca con puntillo      / half with dot      / Semibreve with dot
		  8 - redonda                  / whole              / breve
		  9 - redonda con puntillo     / whole with dot     / breve with dot

cdefgabCDEFGAB -> Notas musicales (dos octavas). Seguida de # para aumentar y de $ para disminuir un semitono
                  Musical notes (two octaves). Followed of # to increase and $ to decrease a half-tone

* ->  toca nota anterior ligada 
      play previous note with ligature

	  ie: 4c* = 8c , 4d2* = 9d , 1e*** = 4e   (3/4) "4cde | *fg |" = "4cd 8e 4fg" 

& -> simbolo de silencio 
     Rest symbol (mute note)
     ie: "4&" Rest of negra/quarter/crotchet time 

t -> tresillo: toca las 3 notas siguientes en dos tiempos 
     triplet: play the 3 following notes in two times
     ie: "4tcde" 3 notes as 2 negra/quarter/crotchet notes

O<n> -> 'O' con numero inmediato de 0 a 8 fija la octava 
        'O' with inmediate number from 0 to 8 fix the octave
        ie: O3 -> Octave 3, O5-> Octava 5

- -> baja una octava 
     decrease one octave

+ -> sube una octava
     increase one octave
     ie: "O4 c -d+ e" == "O4 c O3 d O4 e"

T2, T4, T8 -> Fija el tempo de duracion de las notas 
              Fix the time scale for the notes (ie: 2/2 use T2,  2/4, 3/4, 4/4 use T4, 6/8 use T8)


// simbolos de sincronizacion  
// synchronization symbols

! -> envia una se�al de sincronizacion a los otros canales 
     send a sync signal to the others channels

? -> espera una se�al de sincronizacion 
     wait to a sync signal

// control de instrumento
// instrument control

X<n> -> Seguido de dos numeros del 0 al 9. Fija el numero de instrumento a usar
         Followed for two number from 0 to 9. Fix the instrument number to use
		 ie: X0 ->Instrument 


V<nn> -> Seguido de dos numeros del 0 al 9. Fija el volumen de cada canal de audio
         Followed for two number from 0 to 9. Fix the audio channels volume.

         ie: V99 -> max volume left-right, V59 -> mid volume for left and max for right

// macros

()   -> Asigna un bloque de notas a una macro. La primera macroo tiene indice 0
        let a block of notes as macro. The first macro have the index 0

M<n> -> Seguido de dos numeros del 0 al 9. Ejecuta una macro	
        Followed for two number from 0 to 9. Play one macro

		ie: "(cdef) M0" lets and play the macro 0. it play "cdef" notes
		    "(cdef) (M0 gab) M1"  it play "cdefgab"
			"(cdef) (M0 gab) M0M1" it play "cdef cdef gab" . Parenthesis notes are ignored: only M0 and M1 without it play notes.


// Params by default in the channels

equivalent to: "T4 O3 V99 X0 4"

 Play_Song(
            // song
			"T8 X0 O4"   // time of redonda/ whole/ breve = 8 ticks , instrument 0, octave 4
			"? 2d |"     // wait the sync signal from the 'drum' and play note 'd' as time '2' (corchea / eighth/ quaver note)
			"! 4f 2g | 3a0b2a|" // send a sync pulse and play the notes. Remember '|' is only decorative separator 
			"....",  // more notes
			// chord
			"T8 X1 O3 V33" // time 8 ticks, instrument 1 octave 3 and fix the volume to 3/9 for left-right audio channels
			"?"            // wait the sync signal from the 'drum'
			"? 4d6d"       // wait the sync signal from the 'song' and play notes
			"? 4c6c"       // wait the sync signal from the 'song' and play more notes
			"....",  // more notes
			// drum
			"T8 5BB3BBB ! V66" // time 8 tick, play little drum cymbals intro and change the volume to 6/9
			"? 4ccd ?c2cc4e"   // wait sync signals from the 'song' and play differents parts of the drum
			"....",
			175, // time for the ticks in ms (for example 8c play c note 175x8 ms because T8)
			my_callback // callback to play notes
			);

// callback example

void note_callback(int channel, int instrument, s32 note, int time, int lvolume, int rvolume)
{
//channel=15,14,13,  instrument= 0 to 9, note= (note % 12)+(12*octave), time= time in ms, volume 0 to 255
if(instrument==0)
{
SND_SetSongSampleVoice(channel, VOICE_MONO_8BIT, piano8_smp, piano8_smp+11454, size_piano8_smp);
SND_PlaySongVoice(channel, Note2Freq(note,22050, NOTE(NOTE_A,4)), 0, 0, 0, time-5, lvolume, rvolume);
}
else
{
SND_SetSongSampleVoice(channel, VOICE_MONO_8BIT, organ8_smp, organ8_smp, size_organ8_smp);
SND_PlaySongVoice(channel, Note2Freq(note, 8000, NOTE(NOTE_A,3)), 0, 5, time-8, 3, lvolume, rvolume);
}

}


*/
#endif 

/* internal flags */

#define SONG_STOPPED  128

#define SONG_ERR_OCT  64
#define SONG_ERR_CHN  32
#define SONG_ERR_VOL  16
#define SONG_ERR_TEMPO 8
#define SONG_ERR_PARENTHESIS 4

/*------------------------------------------------------------------------------------------------------------------------------------------------------*/

/* void Play_Song( char *song, char *chord, char *drum, s32 tempo, void (*note_callback)(s32 channel, s32 instrument, s32 note, s32 time, s32 lvolume, s32 rvolume));

Play a song

NOTE: song_lib uses the last 3 voices to play songs (usually 13,14,15)

-- Params ---

song: pointer to the song string. Can be NULL

chord: pointer to the chord string. Can be NULL

drum: pointer to the drum string. Can be NULL

tempo: tick time in milliseconds

note_callback: callback to program and play one note (see callback example in this header file)

return: none

*/

void Play_Song( char *song, char *chord, char *drum, s32 tempo, void (*note_callback)(s32 channel, s32 instrument, s32 note, s32 time, s32 lvolume, s32 rvolume));

/*------------------------------------------------------------------------------------------------------------------------------------------------------*/

/* int Test_Song();

Test if the song is playing

-- Params ---


return: 0 for song stopped or 1 for playing

*/

int Test_Song();

/*------------------------------------------------------------------------------------------------------------------------------------------------------*/

/* void Stop_Song();

Stops the song

-- Params ---

return: none

*/

void Stop_Song();

/*------------------------------------------------------------------------------------------------------------------------------------------------------*/


#ifdef __cplusplus
  }
#endif

#endif
