#define sum_organ8_smp 18568

#define size_organ8_smp 148

extern char organ8_smp[148];
