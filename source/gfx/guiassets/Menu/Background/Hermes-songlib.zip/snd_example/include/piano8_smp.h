#define sum_piano8_smp 1891880

#define size_piano8_smp 12960

extern char piano8_smp[12960];
