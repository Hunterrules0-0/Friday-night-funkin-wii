#define sum_audio_raw 418435

#define size_audio_raw 3304

extern char audio_raw[3304];
