#define sum_mod1_mod 9837290

#define size_mod1_mod 116828

extern char mod1_mod[116828];
