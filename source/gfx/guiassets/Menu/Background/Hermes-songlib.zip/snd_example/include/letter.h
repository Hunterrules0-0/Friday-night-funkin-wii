#define sum_letter 439168

#define size_letter 7168

extern char letter[7168];
