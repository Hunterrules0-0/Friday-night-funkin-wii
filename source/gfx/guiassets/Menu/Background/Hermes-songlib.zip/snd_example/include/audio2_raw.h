#define sum_audio2_raw 1068856

#define size_audio2_raw 8000

extern char audio2_raw[8000];
