/*
Copyright (c) 2008 Francisco Mu�oz 'Hermes' <www.elotrolado.net>
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are 
permitted provided that the following conditions are met:

- Redistributions of source code must retain the above copyright notice, this list of 
  conditions and the following disclaimer. 
- Redistributions in binary form must reproduce the above copyright notice, this list 
  of conditions and the following disclaimer in the documentation and/or other 
  materials provided with the distribution. 
- The names of the contributors may not be used to endorse or promote products derived 
  from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY 
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF 
THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <math.h>
#include <ogcsys.h>
#include <gccore.h>

#include <wiiuse/wpad.h>

#include <stdarg.h>    // for the s_printf function

#define MOD_MANUAL 1


#include "snd.h"       // sound library

#include "../../song_lib/song_lib.h"       // sound library

#include "gcmodplay.h" // modplayer

/* include datas */

#include <letter.h>    // ANSI letters 16x16

#include "mod1_mod.h"  // MOD song

#include "audio_raw.h"  // sound effects in RAW PCM 8 bits (signed)
#include "audio2_raw.h"

/*
#include "soundtrack8_smp.h" // voices for song
#include "celesta8_smp.h"
#include "guitar8_smp.h"
*/
#include "organ8_smp.h"
#include "piano8_smp.h"

/* global datas */

MODPlay mod_track;   // struct for the MOD Player

GXTexObj texObj, texObj2; // textures

void tiling4x4(void *mem, int format, int tx, int ty); // function for texture conversion

/* fonts and s_printf */

static struct tagsizeletter // font size table (use 'sizeletter' as index)
{
 unsigned tx,ty;
} sizelet[9] = {
	{64,64},{32,32},{16,24},{12,16},{16,16},{12,24},{15,24},{128,192},{128,128}
};

int xclip=640; // screen width

int autocenter=0;
unsigned sizeletter=2;    
unsigned bkcolor=0x00000000; 
unsigned color=0xffffffff;
unsigned PX=0,PY=0;

void UploadFontTexture(int select); // upload the font texture (select 1 generate font with mask)

void s_printf( char *format, ...);

/*********************************************************************************************************************************************************/
/* SCREEN VARIABLES                                                                                                                                      */
/*********************************************************************************************************************************************************/

static GXRModeObj	*screenMode;

static void *frameBuffer[2] = {NULL,NULL};
int frame=0;

#define	FIFO_SIZE (256*1024)

static vu8	readyForCopy;
void copy_buffers(u32 count);


int exit_by_reset=0;

void reset_call() {exit_by_reset=1;}



// used to play the song notes

void note_callback(int channel, int instrument, s32 note, int time, int lvolume, int rvolume)
{
if(instrument==1)
{

SND_SetSongSampleVoice(channel, VOICE_MONO_8BIT, piano8_smp, piano8_smp+11454, size_piano8_smp);
SND_PlaySongVoice(channel, Note2Freq(note,22050, NOTE(NOTE_A,4)), 0, 0, 0, time-5, lvolume, rvolume);

}
else
{
SND_SetSongSampleVoice(channel, VOICE_MONO_8BIT, organ8_smp, organ8_smp, size_organ8_smp);
SND_PlaySongVoice(channel, Note2Freq(note, 8000, NOTE(NOTE_A,3)), 0, 5, time-8, 3, lvolume, rvolume);
}

}

void background();

//---------------------------------------------------------------------------------
int main(int argc, char **argv) {
//---------------------------------------------------------------------------------

Mtx	projection;
Mtx	modelView;
GXColor	backgroundColor	= {0, 50, 100,	127};
void *fifoBuffer = NULL;

int time, pitch=48000;
int ticks=0;
int seq=0;
int seq2=0;



int load_song_samples=1;

	// Initialise the video system
	VIDEO_Init();
	
	// This function initialises the attached controllers
	WPAD_Init();
   WPAD_SetIdleTimeout(60*10); // 10 minutes 
	
	// Screen Initialization
    screenMode = VIDEO_GetPreferredMode (NULL);
	
	frameBuffer[0]	= MEM_K0_TO_K1(SYS_AllocateFramebuffer(screenMode));
	frameBuffer[1]	= MEM_K0_TO_K1(SYS_AllocateFramebuffer(screenMode));

	VIDEO_Configure(screenMode);
	VIDEO_SetNextFramebuffer(frameBuffer[frame]);
	VIDEO_SetPostRetraceCallback(copy_buffers);
	VIDEO_SetBlack(FALSE);
	VIDEO_Flush();

	fifoBuffer = MEM_K0_TO_K1(memalign(32,FIFO_SIZE));
	memset(fifoBuffer,0, FIFO_SIZE);

	GX_Init(fifoBuffer, FIFO_SIZE);
	GX_SetCopyClear(backgroundColor, 0x00ffffff);

	GX_SetViewport(0,0,screenMode->fbWidth,screenMode->efbHeight,0,1);
	GX_SetDispCopyYScale((f32)screenMode->xfbHeight/(f32)screenMode->efbHeight);
	GX_SetScissor(0,0,screenMode->fbWidth,screenMode->efbHeight);
	GX_SetDispCopySrc(0,0,screenMode->fbWidth,screenMode->efbHeight);
	GX_SetDispCopyDst(screenMode->fbWidth,screenMode->xfbHeight);
	GX_SetCopyFilter(screenMode->aa,screenMode->sample_pattern,
					 GX_TRUE,screenMode->vfilter);
	GX_SetFieldMode(screenMode->field_rendering,
					((screenMode->viHeight==2*screenMode->xfbHeight)?GX_ENABLE:GX_DISABLE));

	GX_SetCullMode(GX_CULL_NONE);
	GX_CopyDisp(frameBuffer[frame],GX_TRUE);
	GX_SetDispCopyGamma(GX_GM_1_0);

    // Projection Matrix
	guPerspective(projection, 92,  1.333f, 1.0F, 1000.0F);
    GX_LoadProjectionMtx(projection, GX_PERSPECTIVE);
	
	// Vertex descriptor
	GX_ClearVtxDesc();

	GX_SetVtxDesc(GX_VA_POS, GX_DIRECT);
	GX_SetVtxDesc(GX_VA_CLR0, GX_DIRECT);
    GX_SetVtxDesc(GX_VA_TEX0, GX_DIRECT);

    GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_POS,	 GX_POS_XYZ,GX_F32,	0);
	GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_CLR0, GX_CLR_RGBA, GX_RGBA8,	0);
    GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_TEX0, GX_TEX_ST, GX_F32, 0);

    // Upload Font (with Mask)
	UploadFontTexture(1);

    GX_SetBlendMode(GX_BM_BLEND,GX_BL_SRCALPHA,GX_BL_INVSRCALPHA,GX_LO_CLEAR);
 

    SYS_SetResetCallback(reset_call);

	guMtxIdentity(modelView);
	guMtxTransApply(modelView, modelView, 0.0F,	0.0F, -1.0000F);
	GX_LoadPosMtxImm(modelView,	GX_PNMTX0);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// The Demo Sound Starts Here!!!!     

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	SND_Init(INIT_RATE_48000); // Initialize the Sound Lib

	MODPlay_Init(&mod_track);  // Initialize the MOD Library

    SND_Pause(0); // the sound loop is running now


	if (MODPlay_SetMOD (&mod_track, mod1_mod ) < 0 ) // set the MOD song
      {
        MODPlay_Unload (&mod_track);   
      }
	else  
	  {
	    MODPlay_SetVolume( &mod_track, 64,64); // fix the volume to 64 (max 64)
	    MODPlay_Start (&mod_track); // Play the MOD
	  }

#ifdef MOD_MANUAL	 
 mod_track.manual_polling=1; // in this mode when the MOD finish it turn to paused mode (test mod_track.paused). 
#endif                               // You can use it to stops o replace the MOD Song

// NOTE: the MOD player uses the voice 0


// Presentation
	while(1) 
		{


		GX_SetViewport(0,0,screenMode->fbWidth,screenMode->efbHeight,0,1);
		GX_InvVtxCache();
		GX_InvalidateTexAll();

		background();

        guMtxIdentity(modelView);
		guMtxTransApply(modelView, modelView, 0.0F,	0.0F, -1.0000F);
		GX_LoadPosMtxImm(modelView,	GX_PNMTX0);

		GX_ClearVtxDesc();

		GX_SetVtxDesc(GX_VA_POS, GX_DIRECT);
		GX_SetVtxDesc(GX_VA_CLR0, GX_DIRECT);
		GX_SetVtxDesc(GX_VA_TEX0, GX_DIRECT);

		GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_POS,	 GX_POS_XYZ,GX_F32,	0);
		GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_CLR0, GX_CLR_RGBA, GX_RGBA8,	0);
		GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_TEX0, GX_TEX_ST, GX_F32, 0);


		// Call WPAD_ScanPads each loop, this reads the latest controller states
		WPAD_ScanPads();

		// WPAD_ButtonsDown tells us which buttons were pressed in this loop
		// this is a "one shot" state which will not fire again until the button has been released
		u32 pressed = WPAD_ButtonsDown(0);

		// We return to the launcher application via exit
		if ( (pressed & WPAD_BUTTON_HOME) || exit_by_reset) goto exit_to_home;

        time=SND_GetTimerVoice(0)/100; // count in 1/10 seg

        autocenter=0; 
        PX=480;PY=8;color=0xff00ffff;bkcolor=0x40602000;sizeletter=1;s_printf("%2.2i:%2.2i",(time/600) % 60, (time/10) % 60);
#if 1
		if(time<120)
		{
	    autocenter=1;
		PX=0;PY=80;color=0xffffffff;bkcolor=0;sizeletter=2;
        s_printf("Welcome!");
		PX=0;PY+=64;
		s_printf("I am Hermes and this is my first work");
        PX=0;PY+=32;
		s_printf("for the Wii console.");
        PX=0;PY+=64;
		s_printf("This example demostrate my Sound Library");

        PX=0;PY=400;color=0xff00ff00;s_printf("Press HOME or RESET to exit");
		autocenter=0;
		}
		else
		if(time<220)
		{
		PX=0;PY=80;color=0xffffffff;bkcolor=0;sizeletter=2;
		autocenter=1;
        s_printf("To start i am playing a MOD file");
		PX=0;PY+=32;
		s_printf("using the voice 0");
		
		PX=0;PY=400;color=0xff00ff00;s_printf("Press HOME or RESET to exit");
		ticks=0;
        autocenter=0;
        }
		else
		if(time<320)
		{
		int volume;

        autocenter=1;
		PX=0;PY=80;color=0xffffffff;bkcolor=0;sizeletter=2;
        s_printf("Now you can hear as i change");
		PX=0;PY+=32;
		s_printf("the volume of the voice 0 dynamically");
        PX=0;PY+=32;
		s_printf("it change left to right the volume");

        PX=0;PY=400;color=0xff00ff00;s_printf("Press HOME or RESET to exit");
		autocenter=0;

		volume=(ticks<<2) & 255;
        SND_ChangeVolumeVoice(0, 255-volume, volume);
        }
        else
		if(time<490)
		{
		autocenter=1;
		if(time==320) SND_ChangeVolumeVoice(0, 255, 255);
		PX=0;PY=80;color=0xffffffff;bkcolor=0;sizeletter=2;
        s_printf("Now you can hear one voice mixed");
		
		// voice to center
		if(time==350) if(SND_StatusVoice(1)==SND_UNUSED) SND_SetVoice(1, VOICE_MONO_8BIT, 8000, 0, audio2_raw, size_audio2_raw, 255, 255, NULL);
		// voice to left
		if(time==370) if(SND_StatusVoice(1)==SND_UNUSED) SND_SetVoice(1, VOICE_MONO_8BIT, 8000, 0, audio2_raw, size_audio2_raw, 255, 0, NULL);
		// voice to right
		if(time==390) if(SND_StatusVoice(1)==SND_UNUSED) SND_SetVoice(1, VOICE_MONO_8BIT, 8000, 0, audio2_raw, size_audio2_raw, 0, 255, NULL);
		// voice to left-right
		if(time==410) if(SND_StatusVoice(1)==SND_UNUSED) 
			            {SND_SetVoice(1, VOICE_MONO_8BIT, 8000, 0, audio2_raw, size_audio2_raw, 255, 0, NULL);
		                 SND_SetVoice(2, VOICE_MONO_8BIT, 8000, 500, audio2_raw, size_audio2_raw, 0, 255, NULL);
		                }

		if(time==430) if(SND_StatusVoice(1)==SND_UNUSED) 
			            {SND_SetVoice(1, VOICE_MONO_8BIT, 8000, 0, audio2_raw, size_audio2_raw, 255, 255, NULL);
		                 SND_SetVoice(2, VOICE_MONO_8BIT, 8000, 400, audio2_raw, size_audio2_raw, 220, 220, NULL);
						 SND_SetVoice(3, VOICE_MONO_8BIT, 8000, 800, audio2_raw, size_audio2_raw, 180, 180, NULL);
						 SND_SetVoice(4, VOICE_MONO_8BIT, 8000, 1200, audio2_raw, size_audio2_raw, 127, 127, NULL);
		                }

		PX=0;PY+=64;
		if(time>=350)
			{     if(time<370) s_printf("CENTER");
			 else if(time<390) s_printf("LEFT");
			 else if(time<410) s_printf("RIGHT");
			 else if(time<430) s_printf("LEFT-RIGHT!! (two voices)");
             else if(time<470) s_printf("ECHO EFFECT (four voices)");
		    }

		PX=0;PY=400;color=0xff00ff00;s_printf("Press HOME or RESET to exit");
		autocenter=0;
		}
		else
#endif
		{
		PX=0;PY=16;bkcolor=0;sizeletter=2;

		if(load_song_samples)
		{
		load_song_samples=0;
		
		// load the samples for songs

        SND_SetTime(0); // set to 0 the global time
		}
		autocenter=0;
		color=0xff0080ff; s_printf("Pitch of Voice 0: %i Hz",pitch);
 
		autocenter=1;
		PX=0;PY=80;color=0xffffffff;
        s_printf("Now you are in free mode");
		PX=0;PY+=32;
		s_printf(" Press A or B to hear different voices");
		PX=0;PY+=32;
		s_printf("MINUS and PLUS change the Voice 0 Pitch");
		PX=0;PY+=32;
		s_printf("Press 1 and 2 for note to note songs");
		PX=0;PY+=32;
		s_printf("(Use the Wiimote)");
		
       if(pressed & WPAD_BUTTON_A)
		    {
		    SND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_8BIT, 8000, 0, audio2_raw, size_audio2_raw, 255, 255, NULL);
		    SND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_8BIT, 8000, 400, audio2_raw, size_audio2_raw, 220, 220*0, NULL);
			SND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_8BIT, 8000, 800, audio2_raw, size_audio2_raw, 180*0, 180, NULL);
			SND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_8BIT, 8000, 1200, audio2_raw, size_audio2_raw, 127, 127, NULL);
			}
        if(pressed & WPAD_BUTTON_B)
			{
			ticks=0;
			SND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_8BIT, 8000, 0, audio_raw, size_audio_raw, 255, 255, NULL);
			SND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_8BIT, 8000, 20, audio_raw, size_audio_raw, 255, 255, NULL);
            
			}

		if(pressed & WPAD_BUTTON_1)
			{
			

           if(seq==0) {seq=1;seq2=0;mod_track.paused=1;
		             
		              Play_Song(NULL ,NULL,
					  "T4  0tedetded1e 0tedetded1D   (5cf3cf 5cf3cf) M0dd M0dd M0dd  7e3dd7e1ddd0tedetded1D (5c5c5dD 3cccc) (M1e3dE M15e3ee)"
					  "M2M2 M0dd M0dd M0 3fgabd M2 M2",
                       125, note_callback);
		                }
			else {seq=0;seq2=0;mod_track.paused=0;Stop_Song();}
          
		
			
			}
		if(pressed & WPAD_BUTTON_2)
			{
			
			
			if(seq2==0) {Stop_Song();seq2=1;seq=0;mod_track.paused=1;}
			else {seq2=0;seq=0;mod_track.paused=0;Stop_Song();}
			
			}

		if(pressed & WPAD_BUTTON_MINUS) // Change the MOD pitch  
		    {
			pitch-=4000;if(pitch<20000) pitch=20000; SND_ChangePitchVoice(0, pitch);
			}
		if(pressed & WPAD_BUTTON_PLUS)  // Change the MOD pitch  
		    {
			pitch+=4000;if(pitch>96000) pitch=96000; SND_ChangePitchVoice(0, pitch);
			}
		
		if(ticks<30) {PX=0;PY+=96;color=0xff00ffff;sizeletter=1;s_printf("BANG!");
		             sizeletter=2;
					  }

		PX=0;PY=400;color=0xff00ff00;s_printf("Press HOME or RESET to exit");
		autocenter=0;

		}

        // Song generation //
		/*
		    time=SND_GetTime();

            
			// first song
			//if(seq!=0) process_song(&my_song, time);
         
                       
			if(seq==1) { SND_SetSongSampleVoice(2, VOICE_MONO_8BIT, organ8_smp, organ8_smp, size_organ8_smp);
			             SND_SetSongSampleVoice(3, VOICE_MONO_8BIT, organ8_smp, organ8_smp, size_organ8_smp); 
			            time2=time+500;SND_PlaySongVoice(2, Note2Freq(NOTE(NOTE_A,5), 8000, NOTE(NOTE_A,3)), 0, 0, 450, 50, 127, 0); // organ
			            SND_PlaySongVoice(3, Note2Freq(NOTE(NOTE_A,6), 8000, NOTE(NOTE_A,3)), 40, 0, 450, 50, 0, 127);seq++;} // celesta
						else
			if(seq==2 && time>=time2) 
				       {time2=time+500;SND_PlaySongVoice(2, Note2Freq(NOTE(NOTE_B,5), 8000, NOTE(NOTE_A,3)), 0, 0, 450, 50, 127, 0);
				        SND_PlaySongVoice(3, Note2Freq(NOTE(NOTE_B,6), 8000, NOTE(NOTE_A,3)), 40, 0, 450, 50, 0, 127);seq++;}
						else
			if(seq==3 && time>=time2) 
				       {time2=time+500;SND_PlaySongVoice(2, Note2Freq(NOTE(NOTE_G,5), 8000, NOTE(NOTE_A,3)), 0, 0, 450, 50, 127, 0);
				        SND_PlaySongVoice(3, Note2Freq(NOTE(NOTE_G,6), 8000, NOTE(NOTE_A,3)), 40, 0, 450, 50, 0, 127);seq++;}
						else
			if(seq==4 && time>=time2) 
				       {time2=time+500;SND_PlaySongVoice(2, Note2Freq(NOTE(NOTE_G,4), 8000, NOTE(NOTE_A,3)), 0, 0, 450, 50, 127, 0);
			            SND_PlaySongVoice(3, Note2Freq(NOTE(NOTE_G,5), 8000, NOTE(NOTE_A,3)), 40, 0, 450, 50, 0, 127);seq++;}
						else
			if(seq==5 && time>=time2) 
				       {time2=time+500;SND_PlaySongVoice(2, Note2Freq(NOTE(NOTE_D,5), 8000, NOTE(NOTE_A,3)), 0, 0, 950, 50, 127, 0);
				        SND_PlaySongVoice(3, Note2Freq(NOTE(NOTE_D,6), 8000, NOTE(NOTE_A,3)), 40, 0, 950, 50, 0, 127);seq=0;}
	

           */

	      

           
            
			// second song

 
			if(Test_Song()==0 && seq2)
			{
			if(0) // other song
			{
			 Play_Song(
			// song
			"T8 X0 O4 V35 " // Tempo , selected sound, octave, volume
			"(!4f 2g 3a0b2a |  !4g 2e 3c0d2e)" // M0
			"(!3f0e2d 3d$-0b+2c)"             // M1
			"(!5C 3C0b2a | !4g 2e 3c0d2e)"     // M2
			 /* aqui se toca */
			"? 2d | M0 | !4f2d 3d0d$2d | !4e 2d$ -a+& V53 d|"
			"M0 | M1 | !5d d |"
			"V55 M2  | !4f 2d 3d0d$2d | !4e 2d$ -a+ 4& |"
			"M2 | M1 | !5d d",              
				
			// chord
			"T8 X0 O3 V33 ?"
			"(?4d6d ?4c6c ?4a#6a#)"
			"(?4f6f ?4c6c ?4a#6a#)"
			"M0 ?4a2a |"
			"M0 ?5d |"
			"M1 ?4a2a"
			"M1 ?7d",
				
			 // drum
     	    "T8 5BB3BBB ! V66"
        
            ,175, note_callback);
			
			}
			else
				{
				Play_Song("T4  V55 O3 X0"     
                "(3D7D4&2a5D !3C6C4& 3ggb3C3)"
                "?M0 M0 M0 M0 8C**!D**a#** !4FED6C4aDDC4D"
                "8&",
				// chord
				"T4 V33 O4 X1 ? ?4C2D6A ?4C2D6A ?4C2D6A ?4C2E6G ?4C2D6A  X1 ?4FED6C4aDDC4D  \0 4GFEFD", 
                // drum
				"(3ccd)"
                "(M0&0 M0&0 M0& M0&)"
                "M1 ! M1 M1 M1 M1 M1 M0& M0& M0& 0cc2d 0dede&dede8C"
      
                 ,   150, note_callback);  
			 
			
				}
             }

        // test for song 1 finished
        if(Test_Song()==0 && (seq)) {seq=0;mod_track.paused=0;Stop_Song();} 

#ifdef MOD_MANUAL	
	    // test for MOD change
		if(Test_Song()==0)
		   if(mod_track.paused) mod_track.paused=0; // you can change this part to load other MOD song
#endif

        GX_DrawDone();
        readyForCopy = GX_TRUE;

		// Wait for the next frame
		VIDEO_WaitVSync();
		ticks++;
	}


exit_to_home:

	MODPlay_Unload (&mod_track);
	WPAD_Shutdown();
	SND_End();

	return 0;
}

/*********************************************************************************************************************************************************/
/* Texture Tool                                                                                                                                          */
/*********************************************************************************************************************************************************/

void tiling4x4(void *mem,int format,int tx,int ty)
{
int n,m,l;
u16 mem_tile[1024*2];
u16 *p1,*p2;

if(format==0) // color 16 bits
	{
	
	p1=(u16 *) mem;
    p2=(u16 *) &mem_tile[0];

    for(n=0;n<ty;n+=4)
		{
		for(l=0;l<4;l++)
			{
			for(m=0;m<tx;m+=4)
				{
				p2[((l+m)<<2)]=p1[(n+l)*tx+m];
				p2[((l+m)<<2)+1]=p1[(n+l)*tx+m+1];
				p2[((l+m)<<2)+2]=p1[(n+l)*tx+m+2];
				p2[((l+m)<<2)+3]=p1[(n+l)*tx+m+3];
				}
			}
		for(l=0;l<4;l++)
			{
			for(m=0;m<tx;m++)
				{
				p1[(n+l)*tx+m]=p2[(l)*tx+m];
				}
			}
		}
	}
#define INV_COLOR16(x) ((x & 0x83e0) | ((x & 31)<<10) | ((x>>10) & 31))

if(format==1) // color 16 bits (With R and B swap)
	{
	

	p1=(u16 *) mem;
    p2=(u16 *) mem_tile;

    for(n=0;n<ty;n+=4)
		{
		for(l=0;l<4;l++)
			{
			for(m=0;m<tx;m+=4)
				{
				p2[((l+m)<<2)]=p1[(n+l)*tx+m];
				p2[((l+m)<<2)+1]=p1[(n+l)*tx+m+1];
				p2[((l+m)<<2)+2]=p1[(n+l)*tx+m+2];
				p2[((l+m)<<2)+3]=p1[(n+l)*tx+m+3];
				}
			}
		for(l=0;l<4;l++)
			{
			for(m=0;m<tx;m++)
				{
				p1[(n+l)*tx+m]=INV_COLOR16(p2[(l)*tx+m]);
				}
			}
		}
	}
#undef INV_COLOR16
}

/*********************************************************************************************************************************************************/
/* SCREEN TOOL                                                                                                                                           */
/*********************************************************************************************************************************************************/

void copy_buffers(u32 count __attribute__ ((unused)))
{
	if (readyForCopy==GX_TRUE) {
		GX_SetZMode(GX_TRUE, GX_LEQUAL,	GX_TRUE);
		GX_SetColorUpdate(GX_TRUE);
		GX_CopyDisp(frameBuffer[frame],GX_TRUE);
		
		GX_Flush();
        VIDEO_SetNextFramebuffer(frameBuffer[frame]);
		VIDEO_Flush();
	    frame^=1;
		readyForCopy = GX_FALSE;
	}
}

/*********************************************************************************************************************************************************/
/* Font & s_printf                                                                                                                                       */
/*********************************************************************************************************************************************************/

u16 texture[256*256] ATTRIBUTE_ALIGN(32);

void UploadFontTexture(int select)
{

u16 *font2=0;
int n,m,l,pos,pos2;
unsigned char *punt;
unsigned short dat;
unsigned color;


font2=texture;
if(!font2) return;

punt=(unsigned char *) &letter[0];

memset((void *) &font2[0],0,2*256*256);



for(n=32;n<256;n++)
	{
	pos=((n & 15)<<4)+((n>>4)<<12);

	pos2=0;
	for(m=0;m<16;m++)
		{
		dat=punt[0] | (punt[1]<<8);
		punt+=2;
		
		for(l=0;l<16;l++)
			{
            pos2=(l & 3)+((m & 3)<<2)+((l>>2)<<4)+((m>>2)<<10);
			if(dat & 32768) {color=0xffff; 
							}
							else color=0x0000;
			font2[pos+l]=color;dat<<=1;
			
			if(color && select!=0)
				{
				if(l>0) if(!font2[pos+l-256]) font2[pos+l-256]=0x8000;
				if(l<15) if(!font2[pos+l+256]) font2[pos+l+256]=0x8000;
				if(m>0) if(!font2[pos+l-1]) font2[pos+l-1]=0x8000;
				if(m<15) if(!font2[pos+l+1]) font2[pos+l+1]=0x8000;
				}

			}
		pos+=256;
			
		}
	}

tiling4x4(texture,0 ,256,256);

DCFlushRange(texture,256*256*2);
GX_InitTexObj(&texObj, texture, 256, 256,GX_TF_RGB5A3, GX_CLAMP, GX_CLAMP, GX_FALSE);

}


static float tab_x[2048];
static float tab_y[2048];


// elements conversion 

#define XX(a) tab_x[(a+512) & 2047]
#define YY(a) tab_y[(a+512) & 2047]
#define ZZ(a) ((float) ((a)))

#define Get_LE(x) (((x>>24) & 0xff) | ((x>>8) & 0xff00) | ((x<<8) & 0xff0000) | ((x<<24) & 0xff000000))

static void printcad(u32 x, u32 y, u32 z, u32 color, char *cadena,u16 tamx, u16 tamy)
{

int i,c,valueanc;
u16 x0, y0, x1, y1;

static int one=1;

GX_SetBlendMode(GX_BM_BLEND,GX_BL_SRCALPHA,GX_BL_INVSRCALPHA,GX_LO_CLEAR);

if(one)
	{
	int n;
	
    for(n=0;n<2048;n++)
    {
    tab_x[n]=((float)(n-512-320))/240.0f;   
    tab_y[n]=-(((float)(n-512-240))/240.0f);
    }
	one=0;
	}
		
  

  valueanc=0;
			
   for(i=0;i<strlen(cadena);i++)
	{if(i>=xclip/tamx) break;

     c=cadena[i] & 0xff;

	 if(c>=32 && x<xclip)
		{
		x0=((c & 15)<<4);
		x1=x0+15;
		y0=((c & 0xfff0));
		y1=y0+15;
				
        if(bkcolor!=0)	
	     {
         GX_SetTevOrder(GX_TEVSTAGE0, GX_TEXCOORDNULL, GX_TEXMAP_NULL, GX_COLOR0A0);
         GX_SetTevOp(GX_TEVSTAGE0, GX_PASSCLR);
         GX_SetVtxDesc(GX_VA_TEX0, GX_NONE); 
	     
		 GX_Begin(GX_QUADS, GX_VTXFMT0, 4);
		 
		 GX_Position3f32(XX(x),YY(y),ZZ(z));
         GX_Color1u32(Get_LE(bkcolor));
  
         GX_Position3f32(XX(x+tamx),YY(y),ZZ(z));
         GX_Color1u32(Get_LE(bkcolor));

         GX_Position3f32(XX(x+tamx),YY(y+tamy),ZZ(z));
         GX_Color1u32(Get_LE(bkcolor));
 
         GX_Position3f32(XX(x),YY(y+tamy),ZZ(z));
         GX_Color1u32(Get_LE(bkcolor));

	     GX_End();
	     }
   
			
			
	    if(c!=32)
	     {
		 GX_SetVtxDesc(GX_VA_TEX0, GX_DIRECT); // enable texture
		 GX_SetTevOp(GX_TEVSTAGE0, GX_MODULATE);
		 GX_SetTevOrder(GX_TEVSTAGE0, GX_TEXCOORD0, GX_TEXMAP0, GX_COLOR0A0);
		 GX_SetNumChans(1);

		 GX_LoadTexObj(&texObj, GX_TEXMAP0); // select texture

         GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_TEX0, GX_TEX_ST, GX_S16, 9); // 9 bits of precision
		 x0<<=1;y0<<=1;
		 x1<<=1;y1<<=1;
		 y0+=1;

	     GX_Begin(GX_QUADS, GX_VTXFMT0, 4);

		 GX_Position3f32(XX(x),YY(y),ZZ(z));
		 GX_Color1u32(Get_LE(color));
         GX_TexCoord2s16(x0,y0);

		 GX_Position3f32(XX(x+tamx),YY(y),ZZ(z));
		 GX_Color1u32(Get_LE(color));
		 GX_TexCoord2s16(x1,y0);


		 GX_Position3f32(XX(x+tamx),YY(y+tamy),ZZ(z));
		 GX_Color1u32(Get_LE(color));
		 GX_TexCoord2s16(x1,y1);

		 GX_Position3f32(XX(x),YY(y+tamy),ZZ(z));
		 GX_Color1u32(Get_LE(color));
		 GX_TexCoord2s16(x0,y1);


		 GX_End();
		}
	 }
				
   x=x+tamx;

   if(c=='\n') {x=0;y=y+tamy;}
   }
   
   PY=y;PX=x;

   GX_SetBlendMode(GX_BM_NONE,GX_BL_SRCALPHA,GX_BL_INVSRCALPHA,GX_LO_CLEAR);
}


void s_printf( char *format, ...)
{
   va_list	opt;
   u8		buff[2048];

   
    
   va_start(opt, format);
   vsprintf( (void *) buff,format, opt);
   va_end(opt);

if(autocenter) {PX=(xclip-(strlen((char *)buff)*sizelet[sizeletter].tx))/2;}
printcad(PX, PY ,0x0, color, (void *) buff, sizelet[sizeletter].tx, sizelet[sizeletter].ty);

return;
}



/*********************************************************************************************************************************************************/

// background


s16 vertex[] ATTRIBUTE_ALIGN(32) = {
	// x y z
	-30,  30, -30, 	// 0
	 30,  30, -30, 	// 1
	 30,  30,  30, 	// 2
	-30,  30,  30, 	// 3
	 30, -30, -30, 	// 4
	 30, -30,  30, 	// 5
	-30, -30,  30,  // 6
	-30, -30, -30,  // 7

	-50,  50, -30,  // 8 // back
	 50,  50, -30,  // 9
	 50, -50, -30,  // 10
	-50, -50, -30,  // 11
};

	
		
float normal[] ATTRIBUTE_ALIGN(32) = {
	// x y z
0.0f,1.0f,0.0f,
-1.0f,0.0f,0.0f,
0.0f,0.0f,-1.0f,
1.0f,0.0f,0.0f,
0.0f,0.0f,1.0f,
0.0f,-1.0f,0.0f,
}; 


void draw_quad(u8 v0, u8 v1, u8 v2, u8 v3, u8 n) {
//---------------------------------------------------------------------------------

	GX_Position1x8(v0);
    GX_Normal1x8(n);

	GX_Position1x8(v1);
	GX_Normal1x8(n);

	GX_Position1x8(v2);
	GX_Normal1x8(n);

	GX_Position1x8(v3);
	GX_Normal1x8(n);
}

GXLightObj light1, light2, light3;

void  background()
{
Mtx	modelView;
Mtx toWorldInvTrans;
Mtx	mat1,mat2;
int n,m;

static float rotatez = 0.0f;

 
rotatez-=0.005f;

GX_ClearVtxDesc();
 GX_SetVtxDesc(GX_VA_POS, GX_INDEX8);
 GX_SetVtxDesc(GX_VA_CLR0,GX_NONE);
 GX_SetVtxDesc(GX_VA_NRM, GX_INDEX8);
 GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_POS, GX_POS_XYZ, GX_S16, 2);
 GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_CLR0, GX_CLR_RGBA, GX_RGBA8, 0);
 GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_NRM, GX_NRM_XYZ, GX_F32, 0);
 GX_SetArray(GX_VA_POS, vertex, 3*sizeof(s16));

 GX_SetArray(GX_VA_NRM, normal, 3*sizeof(s32));
	DCFlushRange(vertex,sizeof(vertex));
	DCFlushRange(normal,sizeof(normal));

// no texture
GX_SetTevOrder(GX_TEVSTAGE0, GX_TEXCOORDNULL, GX_TEXMAP_NULL, GX_COLOR0A0);
GX_SetTevOp(GX_TEVSTAGE0, GX_PASSCLR);
GX_SetVtxDesc(GX_VA_TEX0, GX_NONE); 

GXColor material= {0xf0, 0xf0, 0xf0, 255};
GXColor ambient = {0,40,80,255};

GXColor material2= {0xf0, 0xf0, 0xf0, 255};
GXColor ambient2 = {0,40/2,80/2,255};

Vector lightPos1={0.0f,0.0f,1700.0f/4};
GXColor clight1 = {0, 15/2, 32/2, 255};


Vector lightPos2={125.0f*cos(-rotatez),125.0f*sin(-rotatez),1700.0f/4};
GXColor clight2 = {127, 0, 0, 255};
GXColor clight3 = {0, 127, 0, 255};

GX_InitLightDir(&light1,0.0f,0.0f,-1.0f);
GX_InitLightPosv(&light1,&lightPos1);
GX_InitLightColor(&light1,clight1);	
GX_InitLightAttn(&light1, -49.0f/2, 50.0f/2, 4.7f, 1.0f, 0.0f, 0.0f);


GX_InitLightDir(&light2,0.0f,0.0f,-1.0f);
GX_InitLightPosv(&light2,&lightPos2);
GX_InitLightColor(&light2,clight2);	
GX_InitLightAttn(&light2,-299.0f, 200.0f, 101.0f , 1.0f, 0.0f, 0.0f);

GX_InitLightDir(&light3,0.0f,0.0f,-1.0f);
GX_InitLightPos(&light3,-lightPos2.x, -lightPos2.y, lightPos2.z);
GX_InitLightColor(&light3,clight3);	
GX_InitLightAttn(&light3,-299.0f, 200.0f, 102.0f , 1.0f, 0.0f, 0.0f);

	
GX_LoadLightObj(&light1,GX_LIGHT0);
GX_LoadLightObj(&light2,GX_LIGHT1);
GX_LoadLightObj(&light3,GX_LIGHT2);

GX_SetChanCtrl(GX_COLOR0A0,GX_ENABLE,GX_SRC_REG, GX_SRC_REG,GX_LIGHT0 | GX_LIGHT1 | GX_LIGHT2,GX_DF_CLAMP,GX_AF_SPOT);



guMtxIdentity(mat1);guMtxIdentity(mat2);

guMtxRotRad(mat1,'Z',rotatez);
guMtxRotRad(mat2,'X',rotatez*4.0f);

for(n=-375;n<375;n+=25)
for(m=-375;m<375;m+=25)
{
guMtxIdentity(modelView);
guMtxTransApply(modelView, modelView, (float) m, (float) (n+7.5f), -200.0000F);

guMtxConcat(mat1, modelView, modelView);


guMtxInverse(modelView,toWorldInvTrans);
guMtxTranspose(toWorldInvTrans,toWorldInvTrans);

GX_LoadPosMtxImm(modelView,	GX_PNMTX0);
GX_LoadNrmMtxImm(toWorldInvTrans, GX_PNMTX0);

GX_SetCurrentMtx(GX_PNMTX0);

// background

GX_SetChanMatColor(GX_COLOR0A0,material2);
GX_SetChanAmbColor(GX_COLOR0A0,ambient2);

 GX_Begin(GX_QUADS, GX_VTXFMT0, 1*4);

		draw_quad(8, 9, 10, 11, 4);
 
	GX_End();

// cube
GX_SetChanMatColor(GX_COLOR0A0,material);
GX_SetChanAmbColor(GX_COLOR0A0,ambient);

guMtxIdentity(modelView);
guMtxTransApply(modelView, modelView, (float) m, (float) (n+30), -200.0000F);

guMtxConcat(modelView, mat2, modelView);
guMtxConcat(mat1, modelView, modelView);


guMtxInverse(modelView,toWorldInvTrans);
guMtxTranspose(toWorldInvTrans,toWorldInvTrans);


GX_LoadPosMtxImm(modelView,	GX_PNMTX0);
GX_LoadNrmMtxImm(toWorldInvTrans, GX_PNMTX0);

 GX_SetCurrentMtx(GX_PNMTX0);

	GX_Begin(GX_QUADS, GX_VTXFMT0, 6*4);


		draw_quad(0, 3, 2, 1, 0); 
		draw_quad(0, 7, 6, 3, 1);
		draw_quad(0, 1, 4, 7, 2);
		draw_quad(1, 2, 5, 4, 3);
		draw_quad(2, 3, 6, 5, 4);
		draw_quad(4, 7, 6, 5, 5);

 
	GX_End();
}
GX_SetChanCtrl(GX_COLOR0A0,GX_ENABLE*0,GX_SRC_REG,GX_SRC_VTX,GX_LIGHTNULL,GX_DF_CLAMP,GX_AF_NONE);
 GX_SetVtxDesc(GX_VA_NRM, GX_NONE);
 }


/*********************************************************************************************************************************************************/
/*                                                                                                                                                       */
/*********************************************************************************************************************************************************/

