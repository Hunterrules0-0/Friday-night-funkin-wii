(c) 2008, Francisco Mu�oz 'Hermes' <www.elotrolado.net> 

soundlib BETA 1.0

*** About snd_oggexample: Put a ogg file named 'sample.ogg' in the root directory of the SD memory to play an external Ogg when the intenal Ogg finish

greetings:

- to Marcansoft (great aid for me :))

- to jiXo (by elotrolado.net support, specially the ftp server to upload my 'little' code)

- WinterMute, shagkur and others that they do possible this.

      